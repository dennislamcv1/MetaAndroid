package com.example.littlelemon.ui.theme

import androidx.compose.material.Typography

val Typography = Typography(
    //TODO: Insert code here
)
